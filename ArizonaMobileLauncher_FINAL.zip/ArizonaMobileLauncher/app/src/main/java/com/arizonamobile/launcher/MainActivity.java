package com.arizonamobile.launcher;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;

public class MainActivity extends Activity {
    private static final int DESIGN_W = 1536;
    private static final int DESIGN_H = 1024;
    private EditText ipField;
    private SharedPreferences prefs;
    private LauncherView background;
    private FrameLayout root;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        prefs = getSharedPreferences("launcher", MODE_PRIVATE);
        root = new FrameLayout(this);
        background = new LauncherView(this);
        root.addView(background, new FrameLayout.LayoutParams(-1, -1));

        addIpField();
        addPlayButtons();
        setContentView(root);
    }

    private GradientDrawable bgDrawable(int fill, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(18);
        d.setStroke(2, stroke);
        return d;
    }

    private void addIpField() {
        ipField = new EditText(this);
        ipField.setSingleLine(true);
        ipField.setHint("IP:PORT сервера");
        ipField.setHintTextColor(0xFF8292AD);
        ipField.setTextColor(Color.WHITE);
        ipField.setTextSize(15);
        ipField.setPadding(18, 0, 18, 0);
        ipField.setInputType(InputType.TYPE_CLASS_TEXT);
        ipField.setBackground(bgDrawable(0xEE0B1628, 0xFF526DFF));
        ipField.setText(prefs.getString("ip", "89.43.33.67:7777"));
        root.addView(ipField);
    }

    private void addPlayButtons() {
        String[] servers = {"Arizona Mobile 1", "Arizona Mobile 2", "Arizona Mobile 3", "Arizona Mobile 4", "Arizona Mobile 5", "Arizona Mobile 6"};
        for (int i = 0; i < servers.length; i++) {
            final String server = servers[i];
            Button b = new Button(this);
            b.setText("ИГРАТЬ");
            b.setTextColor(Color.WHITE);
            b.setTextSize(13);
            b.setAllCaps(false);
            b.setPadding(0, 0, 0, 0);
            b.setBackground(bgDrawable(0xFF4058F5, 0xFF6F82FF));
            b.setOnClickListener(v -> connect(server));
            root.addView(b);
        }
    }

    private void connect(String server) {
        String ip = ipField.getText().toString().trim();
        if (ip.isEmpty()) {
            ipField.requestFocus();
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) imm.showSoftInput(ipField, InputMethodManager.SHOW_IMPLICIT);
            Toast.makeText(this, "Сначала введи IP:PORT сервера", Toast.LENGTH_SHORT).show();
            return;
        }
        prefs.edit().putString("ip", ip).apply();
        String sampAddress = ip.contains(":") ? ip : ip + ":7777";

        // 1) Try the standard SA-MP deep link. This is the preferred path because
        // compatible Arizona/SA-MP clients can receive the server address directly.
        Intent sampIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("samp://" + sampAddress));
        android.content.pm.ResolveInfo resolved = getPackageManager().resolveActivity(
                sampIntent, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY);
        if (resolved != null && resolved.activityInfo != null) {
            try {
                startActivity(sampIntent);
                return;
            } catch (Exception ignored) { }
        }

        // 2) Fallback: find the installed app whose launcher label is Arizona Mod
        // and open it. The IP remains saved in the launcher for the next attempt.
        Intent launcherIntent = findArizonaModIntent();
        if (launcherIntent != null) {
            try {
                startActivity(launcherIntent);
                Toast.makeText(this, "Arizona Mod открыт. Если сервер не подставился автоматически, используй сохранённый IP: " + sampAddress, Toast.LENGTH_LONG).show();
                return;
            } catch (Exception ignored) { }
        }

        Toast.makeText(this, "Arizona Mod не найден. Установи Arizona Mod и попробуй ещё раз.", Toast.LENGTH_LONG).show();
    }

    private Intent findArizonaModIntent() {
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        java.util.List<android.content.pm.ResolveInfo> apps =
                getPackageManager().queryIntentActivities(main, android.content.pm.PackageManager.MATCH_ALL);
        for (android.content.pm.ResolveInfo info : apps) {
            CharSequence labelCs = info.loadLabel(getPackageManager());
            String label = labelCs == null ? "" : labelCs.toString().toLowerCase(java.util.Locale.ROOT);
            String pkg = info.activityInfo == null ? "" : info.activityInfo.packageName.toLowerCase(java.util.Locale.ROOT);
            if (label.contains("arizona mod") || (label.contains("arizona") && label.contains("mod")) ||
                    pkg.contains("arizona") || pkg.contains("arizonamod")) {
                Intent launch = new Intent(Intent.ACTION_MAIN);
                launch.addCategory(Intent.CATEGORY_LAUNCHER);
                launch.setClassName(info.activityInfo.packageName, info.activityInfo.name);
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                return launch;
            }
        }
        return null;
    }

    private void layoutControls(int w, int h) {
        float sx = w / (float) DESIGN_W;
        float sy = h / (float) DESIGN_H;
        // IP field: top-right area of the server card, without hiding the title.
        place(ipField, 650, 374, 390, 52, sx, sy);

        for (int i = 0; i < root.getChildCount(); i++) {
            View v = root.getChildAt(i);
            if (v instanceof Button) {
                int index = buttonIndex(v);
                place(v, 947, 442 + index * 73, 101, 45, sx, sy);
            }
        }
    }

    private int buttonIndex(View target) {
        int n = 0;
        for (int i = 0; i < root.getChildCount(); i++) {
            View v = root.getChildAt(i);
            if (v instanceof Button) {
                if (v == target) return n;
                n++;
            }
        }
        return 0;
    }

    private void place(View v, float x, float y, float width, float height, float sx, float sy) {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                Math.max(1, Math.round(width * sx)), Math.max(1, Math.round(height * sy)));
        v.setLayoutParams(lp);
        v.setX(x * sx);
        v.setY(y * sy);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    class LauncherView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Bitmap bg;
        LauncherView(Context c) {
            super(c);
            bg = BitmapFactory.decodeResource(getResources(),
                    getResources().getIdentifier("launcher_preview", "drawable", c.getPackageName()));
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            if (bg != null) {
                float scale = Math.max(getWidth()/(float)bg.getWidth(), getHeight()/(float)bg.getHeight());
                float bw = bg.getWidth() * scale, bh = bg.getHeight() * scale;
                float left = (getWidth() - bw) / 2f, top = (getHeight() - bh) / 2f;
                c.drawBitmap(bg, null, new RectF(left, top, left + bw, top + bh), p);
            } else c.drawColor(Color.rgb(7,13,22));
        }
        @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            if (root != null && ipField != null) root.post(() -> layoutControls(w, h));
        }
    }
}
