# Arizona Mobile Launcher

Современный нативный Android-проект лаунчера Arizona Mobile.

## Сборка APK

1. Откройте папку `ArizonaMobileLauncher` в Android Studio.
2. Дождитесь Gradle Sync.
3. Выберите **Build → Build APK(s)**.
4. Готовый debug APK появится в:
   `app/build/outputs/apk/debug/app-debug.apk`

Проект сделан без сторонних библиотек: интерфейс работает как нативный Android View, а предоставленный дизайн используется как основной экран.

## Что уже есть
- Landscape-интерфейс
- Полноэкранный режим
- Современный тёмный дизайн
- Экран выбора серверов
- Навигационные области
- Обработка нажатий
- Иконка приложения/название Arizona Mobile


## Сборка прямо с телефона через GitHub Actions

1. Создайте репозиторий на GitHub.
2. Загрузите в него содержимое этой папки.
3. Откройте вкладку **Actions**.
4. Выберите **Build APK** и нажмите **Run workflow**.
5. После завершения откройте запуск workflow и скачайте артефакт **ArizonaMobileLauncher-APK**.
