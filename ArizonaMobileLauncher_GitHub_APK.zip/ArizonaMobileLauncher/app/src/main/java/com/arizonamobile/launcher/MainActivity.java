package com.arizonamobile.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.Toast;
import android.content.Context;
import android.content.res.Resources;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(new LauncherView(this));
    }

    static class LauncherView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Bitmap bg;
        float sx = 1f, sy = 1f;
        RectF r = new RectF();

        LauncherView(Context c) {
            super(c);
            bg = BitmapFactory.decodeResource(getResources(),
                    getResources().getIdentifier("launcher_preview", "drawable", c.getPackageName()));
            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            setFocusable(true);
        }

        void text(Canvas c, String s, float x, float y, float size, int color, boolean bold) {
            p.setColor(color);
            p.setTextSize(size);
            p.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
            c.drawText(s, x, y, p);
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            if (bg != null) {
                float scale = Math.max(getWidth()/(float)bg.getWidth(), getHeight()/(float)bg.getHeight());
                float w = bg.getWidth()*scale, h = bg.getHeight()*scale;
                float left=(getWidth()-w)/2f, top=(getHeight()-h)/2f;
                c.drawBitmap(bg, null, new RectF(left, top, left+w, top+h), p);
            } else {
                c.drawColor(Color.rgb(7,13,22));
            }

            // Invisible interaction overlay: the artwork remains the main visual.
            // A subtle top label confirms this is the native app.
            text(c, "ARIZONA MOBILE", 28, 42, 17, Color.WHITE, true);
            text(c, "v1.0.0", getWidth()-82, getHeight()-18, 12, 0xFF9AA8BE, false);
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            if (e.getAction() != MotionEvent.ACTION_UP) return true;
            float x=e.getX(), y=e.getY();

            // Main server Play buttons on the supplied 1536x1024 design.
            float scaleX=getWidth()/1536f, scaleY=getHeight()/1024f;
            float designX=x/scaleX, designY=y/scaleY;

            if (designX >= 945 && designX <= 1050 && designY >= 435 && designY <= 875) {
                Toast.makeText(getContext(), "Выберите сервер — подключение к игре можно добавить здесь.", Toast.LENGTH_SHORT).show();
                return true;
            }
            if (designX < 290 && designY > 120 && designY < 500) {
                Toast.makeText(getContext(), "Раздел навигации", Toast.LENGTH_SHORT).show();
                return true;
            }
            if (designX >= 1090 && designY >= 380 && designY <= 900) {
                Toast.makeText(getContext(), "Новости и промокоды", Toast.LENGTH_SHORT).show();
                return true;
            }
            return true;
        }
    }
}
